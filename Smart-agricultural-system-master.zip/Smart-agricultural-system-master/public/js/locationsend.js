/*function locationsend()
{
	 const username = $("#ipUsername").val();
      const password = $("#ipPassword").val();
      var city = document.getElementById("search_categories").value
      $.post("http://localhost:3000/login", { location: city }, (data, status) =>
       {
       	alert('Sending to d server'+city);
        if (status === 'success')
          alert(`Login success\n${data}`);
        else
          alert("Server Not running");

      });
}*/